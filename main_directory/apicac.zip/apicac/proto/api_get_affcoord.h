/* api_get_affcoord.c */
void cac_get_affine_coordinates(double *affcoord, int set_size, double *set_coord, int ctrlpoints_size, double *ctrlpoints_coord);
void cac_get_affine_coordinates_pixel(double *affcoord, double coord_x, double coord_y, int ctrlpoints_size, double *ctrlpoints_coord);
