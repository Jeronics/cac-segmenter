/* api_utils.c */
void cac_error(char *str);
void *cac_xmalloc(size_t size);
